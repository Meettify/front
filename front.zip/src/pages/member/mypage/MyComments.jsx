const MyComments = () => {
    return (
        <div>
            <h2>댓글 단 글</h2>
            <p>댓글이 없습니다.</p>
        </div>
    );
};

export default MyComments;