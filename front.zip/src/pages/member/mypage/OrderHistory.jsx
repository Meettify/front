const OrderHistory = () => {
    return (
        <div>
            <h2>상품 주문 내역</h2>
            <p>주문한 상품이 없습니다.</p>
        </div>
    );
};

export default OrderHistory;