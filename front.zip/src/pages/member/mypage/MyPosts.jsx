const MyPosts = () => {
    return (
        <div>
            <h2>내가 작성한 글</h2>
            <p>작성한 글이 없습니다.</p>
        </div>
    );
};

export default MyPosts;