const MeetHistory = () => {
    return (
        <div>
            <h2>모임 가입 신청 내역</h2>
            <p>가입한 모임이 없습니다.</p>
        </div>
    );
};

export default MeetHistory;