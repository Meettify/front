import React from "react";

import MeetCategory from "../../components/meet/MeetCategory";

const MeetPage = () => {

    return (
        <MeetCategory/>
    );
};

export default MeetPage;